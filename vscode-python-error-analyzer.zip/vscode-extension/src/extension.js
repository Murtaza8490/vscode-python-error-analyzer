"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.activate = activate;
exports.deactivate = deactivate;
const vscode = require("vscode");
const diagnosticProvider_1 = require("./diagnosticProvider");
const quickFixProvider_1 = require("./quickFixProvider");
function activate(context) {
    console.log('Python Error Analyzer is now active');
    const diagnosticProvider = new diagnosticProvider_1.DiagnosticProvider();
    const quickFixProvider = new quickFixProvider_1.QuickFixProvider();
    // Register the diagnostic collection
    const diagnosticCollection = vscode.languages.createDiagnosticCollection('python-error-analyzer');
    context.subscriptions.push(diagnosticCollection);
    // Register event handlers
    context.subscriptions.push(vscode.workspace.onDidChangeTextDocument(event => {
        if (event.document.languageId === 'python') {
            diagnosticProvider.analyzePythonCode(event.document, diagnosticCollection);
        }
    }));
    // Register code action provider
    context.subscriptions.push(vscode.languages.registerCodeActionsProvider('python', quickFixProvider, {
        providedCodeActionKinds: [
            vscode.CodeActionKind.QuickFix
        ]
    }));
    // Initial analysis of open documents
    if (vscode.window.activeTextEditor) {
        diagnosticProvider.analyzePythonCode(vscode.window.activeTextEditor.document, diagnosticCollection);
    }
}
function deactivate() {
    console.log('Python Error Analyzer is now deactivated');
}
//# sourceMappingURL=extension.js.map