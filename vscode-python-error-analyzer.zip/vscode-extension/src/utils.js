"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getLineIndentation = getLineIndentation;
exports.formatErrorMessage = formatErrorMessage;
exports.generateSuggestionMessage = generateSuggestionMessage;
function getLineIndentation(line) {
    const match = line.match(/^(\s*)/);
    return match ? match[1].length : 0;
}
function formatErrorMessage(message) {
    return message
        .replace(/\n/g, ' ')
        .replace(/\s+/g, ' ')
        .trim();
}
function generateSuggestionMessage(error, suggestion) {
    return `Error: ${error}\nSuggestion: ${suggestion}`;
}
//# sourceMappingURL=utils.js.map