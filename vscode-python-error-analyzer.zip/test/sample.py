# Test file with various Python errors

# Undefined variable error
print(undefined_variable)

# Syntax error
if True
    print("Missing colon")

# Indentation error
def test_function():
print("Wrong indentation")

# Multiple errors on same line
if x print("Multiple errors")

# Import error
from nonexistent_module import something
